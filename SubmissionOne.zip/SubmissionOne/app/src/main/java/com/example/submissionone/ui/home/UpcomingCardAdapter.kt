package com.example.submissionone.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submissionone.R
import com.example.submissionone.data.response.ListEventsItem

class UpcomingCardAdapter(private val items: List<ListEventsItem>) : RecyclerView.Adapter<UpcomingCardAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data: ListEventsItem)
    }

    fun setOnClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageCover = itemView.findViewById<ImageView>(R.id.imageView)
        val textTitle = itemView.findViewById<TextView>(R.id.textViewCarousel)

//        fun bind(data: ListEventsItem) {
//            Glide.with(itemView.context)
//                .load(data)
//                .into(imageCover)
//            textTitle.text = data.name
//        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_carousel, parent, false)
        return ListViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val imageLogo = items[position].mediaCover
        val name = items[position].name
        Glide.with(holder.itemView.context)
            .load(imageLogo)
            .into(holder.imageCover)
        holder.textTitle.text = name


        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(items[position])
        }
    }
}