package com.example.submissionone.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submissionone.R
import com.example.submissionone.data.response.ListEventsItem
import org.jsoup.Jsoup

class FinishedListAdapter(private val event: List<ListEventsItem>) : RecyclerView.Adapter<FinishedListAdapter.ListViewHolder>() {

    private lateinit var onCampusItemClickCallback: OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data: ListEventsItem)
    }

    fun setOnClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onCampusItemClickCallback = onItemClickCallback
    }

    class ListViewHolder(item: View): RecyclerView.ViewHolder(item) {
        val imgCover: ImageView = item.findViewById(R.id.img_item_photo)
        val nameEvent: TextView = item.findViewById(R.id.tv_item_name)
        val descriptionEvent: TextView = item.findViewById(R.id.tv_item_description)


    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.card_list_event, parent, false)
        return ListViewHolder(view)
    }

    fun htmlToPlainText(html: String): String {
        return Jsoup.parse(html).text()
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val mediaCover = event[position].mediaCover
        val name = event[position].name
        val description = event[position].description
        Glide.with(holder.itemView.context)
            .load(mediaCover)
            .into(holder.imgCover)
        holder.nameEvent.text = name
        holder.descriptionEvent.text = htmlToPlainText(description)

        holder.itemView.setOnClickListener {
            onCampusItemClickCallback.onItemClicked(event[position])
        }
    }

    override fun getItemCount(): Int = event.size


}