package com.example.submissionone.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.submissionone.data.response.ListEventsItem
import com.example.submissionone.databinding.FragmentHomeBinding
import com.example.submissionone.ui.detail.DetailEventActivity

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private lateinit var rvUpcoming : RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val layoutManagerUpcoming = LinearLayoutManager(context)
        binding.rvUpcomingPreview.layoutManager = layoutManagerUpcoming
        val itemDecoration = DividerItemDecoration(context, layoutManagerUpcoming.orientation)
        binding.rvUpcomingPreview.addItemDecoration(itemDecoration)

        val layoutManagerFinished = LinearLayoutManager(context)
        binding.rvFinishedPreview.layoutManager = layoutManagerFinished
        val itemDecorationFinished = DividerItemDecoration(context, layoutManagerFinished.orientation)
        binding.rvFinishedPreview.addItemDecoration(itemDecorationFinished)

//        searchEvent = binding.searchView

        rvUpcoming = binding.rvUpcomingPreview

        binding.errorMessageUpcomingEvetns.visibility = View.GONE
        binding.errorMessageFinishedEvents.visibility = View.GONE

        homeViewModel.isSuccessUpcoming.observe(viewLifecycleOwner) { successFetch ->
            if (successFetch) {
                homeViewModel.upcomingEvent.observe(viewLifecycleOwner) { events ->
                    if (events.size > 5) {
                        val limitEventUpcoming = events.take(5)
                        setCardUpcomingEvent(limitEventUpcoming)
                    } else {
                        setCardUpcomingEvent(events)
                    }
                }
            } else {
                binding.errorMessageUpcomingEvetns.visibility = View.VISIBLE
//                binding.errorMessageUpcomingEvetns.text = "Error Fetching Data: ${homeViewModel.messageUpcoming}"
            }
        }

        homeViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            setLoadState(isLoading)
        }

        homeViewModel.isSuccessFinished.observe(viewLifecycleOwner) { successFetch ->
            if (successFetch) {
                homeViewModel.finishedEvent.observe(viewLifecycleOwner) { events ->
                    if (events.size > 5) {
                        val limitEventFinished = events.take(5)
                        setListFinishedEvent(limitEventFinished)
                    } else {
                        setListFinishedEvent(events)
                    }
                }
            } else {
                binding.errorMessageFinishedEvents.visibility = View.VISIBLE
            }
        }

        return root
    }

    fun setCardUpcomingEvent(list: List<ListEventsItem>) {
        rvUpcoming.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        val adapter = UpcomingCardAdapter(list)
        rvUpcoming.adapter = adapter

        adapter.setOnClickCallback(object : UpcomingCardAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ListEventsItem) {
                val moveIntent = Intent(context, DetailEventActivity::class.java)
                moveIntent.putExtra(DetailEventActivity.EXTRA_EVENT_ID, data.id)
                startActivity(moveIntent)
            }

        })
    }

    fun setListFinishedEvent(list: List<ListEventsItem>) {
        val adapter = FinishedListAdapter(list)
        binding.rvFinishedPreview.adapter = adapter
        adapter.setOnClickCallback(object : FinishedListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ListEventsItem) {
                val moveIntent = Intent(context, DetailEventActivity::class.java)
                moveIntent.putExtra(DetailEventActivity.EXTRA_EVENT_ID, data.id)
                startActivity(moveIntent)
            }
        })
    }

    fun setLoadState(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}